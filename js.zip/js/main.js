
function main() {

(function () {
  // jQuery Parallax
  function initParallax() {
    $('#intro').parallax("100%", 0.1);
    $('#services').parallax("100%", 0.1);
    $('#aboutimg').parallax("100%", 0.1);	
    $('#testimonials').parallax("100%", 0.1);
    $('#myid').parallax("100%", 0.1);
    $('#learn-app').parallax("100%", 0.1);
    $('#future-web').parallax("100%", 0.1);
    $('#about-me').parallax("100%", 0.1);
    $('#freecharge-android').parallax("100%", 0.1);
    

  }
  initParallax();


}());


}
main();